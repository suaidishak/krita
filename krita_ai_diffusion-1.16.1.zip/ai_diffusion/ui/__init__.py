"""Widgets for AI diffusion workflows."""
