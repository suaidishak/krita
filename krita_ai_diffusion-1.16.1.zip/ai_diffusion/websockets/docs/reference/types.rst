Types
=====

.. automodule:: websockets.typing

    .. autodata:: Data

    .. autodata:: LoggerLike

    .. autodata:: Origin

    .. autodata:: Subprotocol

    .. autodata:: ExtensionName

    .. autodata:: ExtensionParameter

.. autodata:: websockets.protocol.Event

.. autodata:: websockets.datastructures.HeadersLike

.. autodata:: websockets.datastructures.SupportsKeysAndGetItem
