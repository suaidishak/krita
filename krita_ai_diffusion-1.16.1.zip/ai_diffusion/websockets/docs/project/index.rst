About websockets
================

This is about websockets-the-project rather than websockets-the-software.

.. toctree::
   :titlesonly:

   changelog
   contributing
   license
   For enterprise <tidelift>
