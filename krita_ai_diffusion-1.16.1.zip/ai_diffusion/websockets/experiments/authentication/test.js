// for connecting to WebSocket servers
var token = document.body.dataset.token;

// for test assertions only
const params = new URLSearchParams(window.location.search);
var user = params.get("user");
