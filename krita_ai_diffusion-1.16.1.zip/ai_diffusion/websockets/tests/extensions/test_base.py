from websockets.extensions.base import *


# Abstract classes don't provide any behavior to test.
